package solutions.part4.java10;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Beispielprogramm für den Workshop "Best of Java 9, 10 und 11" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class Exercise2a_UnmodifiableCollections 
{
	public static void main(String[] args) 
	{
		final List<String> words = List.of("Hello", "World");
		
		// Kopie Variante 1
		final List<String> copyOfWords1 = List.copyOf(words);
		
		// Kopie Variante 2
		final List<String> copyOfWords2 = words.stream().collect(Collectors.toUnmodifiableList());
		
		System.out.println(copyOfWords1.getClass());		
		System.out.println(copyOfWords2.getClass());
	}
}
