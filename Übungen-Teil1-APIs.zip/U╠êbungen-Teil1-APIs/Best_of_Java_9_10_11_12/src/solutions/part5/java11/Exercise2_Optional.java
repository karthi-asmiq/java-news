package solutions.part5.java11;

import java.util.Optional;
import java.util.stream.Stream;

/**
 * Beispielprogramm für den Workshop "Best of Java 9, 10 und 11" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class Exercise2_Optional 
{
	public static void main(String[] args) 
	{
		final Optional<String> optName = Optional.of("Michael");
		
		final Stream<String> nameStream = asStream(optName);
		final String result = nameStream.filter(str -> str.startsWith("X")).findFirst().orElse("Not Found");
		System.out.println(result);
	}

	static <T> Stream<T> asStream(final Optional<T> opt)
	{
		if (opt.isEmpty())
		{
			return Stream.empty();
		}
		
		return Stream.of(opt.get());
	}
}
