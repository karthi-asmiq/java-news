package exercises.part4.java10;

import java.util.Arrays;
import java.util.List;

/**
 * Beispielprogramm für den Workshop "Best of Java 9, 10 und 11" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class Exercise2b_UnmodifiableCollections 
{
	public static void main(String[] args) 
	{
		final String[] nameArray = { "Tim", "Tom", "Mike" };
		
		// 3 Varianten von unmodifizierbaren Listen
		final List<String> names1 = Arrays.asList(nameArray);
		final List<String> names2 = List.of(nameArray);
		final List<String> names3 = List.of("Tim", "Tom", "Mike");
		
		// Modifikation im Array
		nameArray[2] = "Michael";
		
		// TODO
	}
}
