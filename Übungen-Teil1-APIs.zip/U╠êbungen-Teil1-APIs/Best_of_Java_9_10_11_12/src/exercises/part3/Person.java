package exercises.part3;

public class Person 
{

	public int getAge() {
		
		return 0;
	}

}
