module timeclient {
	requires timeserver;
}