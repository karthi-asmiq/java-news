package com.timeexample.services;

import java.time.LocalDateTime;

public class TimeUtils 
{
	public static LocalDateTime getCurrentTime()
	{
		return LocalDateTime.now();
	} 
}
