module timeclient {
	requires timeservice;
	
	uses com.timeexample.spi.TimeService;
}